/**
* @file Dugum.cpp
* @description Bağlı listeler ile işlemler
* @course 2. öğrenim C grubu
* @assignment 1. ödev
* @date 05.11.2024
* @author Melike Demirtaş melike.demirtas@ogr.sakarya.edu.tr
*/
#include "Dugum.hpp"
Dugum::Dugum(char gen)
{
    this->gen=gen;
    sonraki = nullptr;
}