#ifndef Dugum_hpp
#define Dugum_hpp

class Dugum
{
public:
    
    Dugum(char veri);
    char gen;
    Dugum* sonraki;

};

#endif